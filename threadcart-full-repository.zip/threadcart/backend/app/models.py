from datetime import datetime
from sqlalchemy import String,Integer,Numeric,Boolean,ForeignKey,Text,DateTime
from sqlalchemy.orm import Mapped,mapped_column,relationship
from .database import Base
class User(Base):
 __tablename__='users'; id:Mapped[int]=mapped_column(primary_key=True); name:Mapped[str]=mapped_column(String(120)); email:Mapped[str]=mapped_column(String(255),unique=True,index=True); password_hash:Mapped[str]=mapped_column(String(255)); role:Mapped[str]=mapped_column(String(20),default='CUSTOMER'); created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class Category(Base):
 __tablename__='categories'; id:Mapped[int]=mapped_column(primary_key=True); name:Mapped[str]=mapped_column(String(100),unique=True); description:Mapped[str]=mapped_column(Text,default=''); is_active:Mapped[bool]=mapped_column(Boolean,default=True)
class Product(Base):
 __tablename__='products'; id:Mapped[int]=mapped_column(primary_key=True); name:Mapped[str]=mapped_column(String(200),index=True); description:Mapped[str]=mapped_column(Text); price:Mapped[float]=mapped_column(Numeric(10,2)); discount_price:Mapped[float|None]=mapped_column(Numeric(10,2),nullable=True); category_id:Mapped[int]=mapped_column(ForeignKey('categories.id')); brand:Mapped[str]=mapped_column(String(100),default='ThreadCart'); image_url:Mapped[str]=mapped_column(String(1000)); stock_quantity:Mapped[int]=mapped_column(Integer,default=0); sizes:Mapped[str]=mapped_column(String(100),default='S,M,L,XL'); is_active:Mapped[bool]=mapped_column(Boolean,default=True); created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class Cart(Base):
 __tablename__='cart'; id:Mapped[int]=mapped_column(primary_key=True); user_id:Mapped[int]=mapped_column(ForeignKey('users.id'),unique=True)
class CartItem(Base):
 __tablename__='cart_items'; id:Mapped[int]=mapped_column(primary_key=True); cart_id:Mapped[int]=mapped_column(ForeignKey('cart.id')); product_id:Mapped[int]=mapped_column(ForeignKey('products.id')); size:Mapped[str]=mapped_column(String(10)); quantity:Mapped[int]=mapped_column(Integer)
class Order(Base):
 __tablename__='orders'; id:Mapped[int]=mapped_column(primary_key=True); order_number:Mapped[str]=mapped_column(String(40),unique=True,index=True); user_id:Mapped[int]=mapped_column(ForeignKey('users.id')); total_amount:Mapped[float]=mapped_column(Numeric(10,2)); shipping_address:Mapped[str]=mapped_column(Text); payment_method:Mapped[str]=mapped_column(String(40)); payment_status:Mapped[str]=mapped_column(String(30),default='PENDING'); order_status:Mapped[str]=mapped_column(String(30),default='PENDING'); created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class OrderItem(Base):
 __tablename__='order_items'; id:Mapped[int]=mapped_column(primary_key=True); order_id:Mapped[int]=mapped_column(ForeignKey('orders.id')); product_id:Mapped[int]=mapped_column(ForeignKey('products.id')); product_name:Mapped[str]=mapped_column(String(200)); size:Mapped[str]=mapped_column(String(10)); quantity:Mapped[int]=mapped_column(Integer); unit_price:Mapped[float]=mapped_column(Numeric(10,2)); subtotal:Mapped[float]=mapped_column(Numeric(10,2))
