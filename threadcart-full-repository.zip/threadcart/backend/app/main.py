import os
from uuid import uuid4
from fastapi import FastAPI,Depends,HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import or_
from .database import Base,engine,get_db
from .models import User,Category,Product,Cart,CartItem,Order,OrderItem
from .auth import hash_password,verify_password,token,current_user,admin_user
from pydantic import BaseModel,EmailStr,Field
app=FastAPI(title='ThreadCart API',version='1.0.0')
class Register(BaseModel): name:str; email:EmailStr; password:str=Field(min_length=8)
class Login(BaseModel): email:EmailStr; password:str
class ProductIn(BaseModel): name:str; description:str; price:float; discount_price:float|None=None; category_id:int; brand:str='ThreadCart'; image_url:str; stock_quantity:int=0; sizes:str='S,M,L,XL'; is_active:bool=True
class CartIn(BaseModel): product_id:int; size:str; quantity:int=Field(gt=0)
class Checkout(BaseModel): shipping_address:str=Field(min_length=10); payment_method:str='TEST_CARD'
class Status(BaseModel): status:str
@app.on_event('startup')
def startup():
 Base.metadata.create_all(engine); db=next(get_db())
 try:
  if not db.query(User).filter_by(email=os.getenv('ADMIN_EMAIL','admin@threadcart.local')).first(): db.add(User(name='ThreadCart Admin',email=os.getenv('ADMIN_EMAIL','admin@threadcart.local'),password_hash=hash_password(os.getenv('ADMIN_PASSWORD','Admin@12345')),role='ADMIN'))
  if db.query(Category).count()==0:
   for n in ['Men','Women','Kids','T-Shirts','Shirts','Jeans','Dresses','Jackets','Hoodies']: db.add(Category(name=n,description=f'{n} collection'))
   db.commit()
  if db.query(Product).count()==0:
   cats={c.name:c.id for c in db.query(Category).all()}; data=[('Oversized Black T-Shirt','Heavy cotton oversized tee',899,'T-Shirts'),('Classic White Shirt','Everyday regular-fit shirt',1299,'Shirts'),('Slim Fit Blue Jeans','Stretch denim jeans',1799,'Jeans'),('Floral Summer Dress','Lightweight printed dress',2199,'Dresses'),('Everyday Hoodie','Soft fleece hoodie',1599,'Hoodies'),('Denim Jacket','Classic denim outerwear',2499,'Jackets')]
   for n,d,p,c in data: db.add(Product(name=n,description=d,price=p,category_id=cats[c],brand='ThreadCart',image_url='https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80',stock_quantity=50))
  db.commit()
 finally: db.close()
@app.get('/api/health')
def health(): return {'status':'healthy'}
@app.post('/api/auth/register')
def register(x:Register,db:Session=Depends(get_db)):
 if db.query(User).filter_by(email=x.email).first(): raise HTTPException(409,'Email already registered')
 u=User(name=x.name,email=x.email,password_hash=hash_password(x.password)); db.add(u); db.commit(); db.refresh(u); return {'access_token':token(u),'user':{'id':u.id,'name':u.name,'email':u.email,'role':u.role}}
@app.post('/api/auth/login')
def login(x:Login,db:Session=Depends(get_db)):
 u=db.query(User).filter_by(email=x.email).first()
 if not u or not verify_password(x.password,u.password_hash): raise HTTPException(401,'Invalid email or password')
 return {'access_token':token(u),'user':{'id':u.id,'name':u.name,'email':u.email,'role':u.role}}
@app.get('/api/auth/me')
def me(u=Depends(current_user)): return {'id':u.id,'name':u.name,'email':u.email,'role':u.role}
@app.get('/api/categories')
def categories(db:Session=Depends(get_db)): return db.query(Category).filter_by(is_active=True).all()
@app.get('/api/products')
def products(search:str='',category_id:int|None=None,db:Session=Depends(get_db)):
 q=db.query(Product).filter_by(is_active=True)
 if search:q=q.filter(or_(Product.name.ilike(f'%{search}%'),Product.brand.ilike(f'%{search}%')))
 if category_id:q=q.filter_by(category_id=category_id)
 return q.order_by(Product.created_at.desc()).all()
@app.get('/api/products/{pid}')
def product(pid:int,db:Session=Depends(get_db)):
 p=db.get(Product,pid)
 if not p or not p.is_active:raise HTTPException(404,'Product not found')
 return p
@app.post('/api/products')
def create(x:ProductIn,db:Session=Depends(get_db),_=Depends(admin_user)):
 p=Product(**x.model_dump());db.add(p);db.commit();db.refresh(p);return p
@app.put('/api/products/{pid}')
def update(pid:int,x:ProductIn,db:Session=Depends(get_db),_=Depends(admin_user)):
 p=db.get(Product,pid)
 if not p:raise HTTPException(404,'Product not found')
 for k,v in x.model_dump().items():setattr(p,k,v)
 db.commit();db.refresh(p);return p
@app.delete('/api/products/{pid}')
def delete(pid:int,db:Session=Depends(get_db),_=Depends(admin_user)):
 p=db.get(Product,pid)
 if not p:raise HTTPException(404,'Product not found')
 p.is_active=False;db.commit();return {'message':'Product deactivated'}
def cart(u,db):
 c=db.query(Cart).filter_by(user_id=u.id).first()
 if not c:c=Cart(user_id=u.id);db.add(c);db.commit();db.refresh(c)
 return c
@app.get('/api/cart')
def getcart(u=Depends(current_user),db:Session=Depends(get_db)):
 c=cart(u,db);return [{'id':i.id,'product_id':i.product_id,'size':i.size,'quantity':i.quantity} for i in db.query(CartItem).filter_by(cart_id=c.id).all()]
@app.post('/api/cart/items')
def add(x:CartIn,u=Depends(current_user),db:Session=Depends(get_db)):
 p=db.get(Product,x.product_id)
 if not p or not p.is_active:raise HTTPException(404,'Product not found')
 if x.quantity>p.stock_quantity:raise HTTPException(400,'Insufficient stock')
 if x.size not in p.sizes.split(','):raise HTTPException(400,'Invalid size')
 c=cart(u,db);i=next((i for i in db.query(CartItem).filter_by(cart_id=c.id,product_id=p.id,size=x.size).all()),None)
 if i:i.quantity+=x.quantity
 else:db.add(CartItem(cart_id=c.id,product_id=p.id,size=x.size,quantity=x.quantity))
 db.commit();return {'message':'Added to cart'}
@app.delete('/api/cart/items/{iid}')
def remove(iid:int,u=Depends(current_user),db:Session=Depends(get_db)):
 c=cart(u,db);i=db.get(CartItem,iid)
 if not i or i.cart_id!=c.id:raise HTTPException(404,'Cart item not found')
 db.delete(i);db.commit();return {'message':'Removed'}
@app.post('/api/orders')
def checkout(x:Checkout,u=Depends(current_user),db:Session=Depends(get_db)):
 c=cart(u,db);items=db.query(CartItem).filter_by(cart_id=c.id).all()
 if not items:raise HTTPException(400,'Cart is empty')
 o=Order(order_number='TC-'+uuid4().hex[:10].upper(),user_id=u.id,total_amount=0,shipping_address=x.shipping_address,payment_method=x.payment_method,payment_status='PAID' if x.payment_method=='TEST_CARD' else 'PENDING',order_status='CONFIRMED');db.add(o);db.flush();total=0
 for i in items:
  p=db.get(Product,i.product_id)
  if i.quantity>p.stock_quantity:raise HTTPException(400,f'Insufficient stock for {p.name}')
  price=float(p.discount_price or p.price);sub=price*i.quantity;total+=sub;p.stock_quantity-=i.quantity;db.add(OrderItem(order_id=o.id,product_id=p.id,product_name=p.name,size=i.size,quantity=i.quantity,unit_price=price,subtotal=sub));db.delete(i)
 o.total_amount=total;db.commit();return {'order_number':o.order_number,'total_amount':total,'status':o.order_status}
@app.get('/api/orders')
def orders(u=Depends(current_user),db:Session=Depends(get_db)):return db.query(Order).filter_by(user_id=u.id).order_by(Order.created_at.desc()).all()
@app.get('/api/admin/dashboard')
def dashboard(db:Session=Depends(get_db),_=Depends(admin_user)):
 os_=db.query(Order).all();return {'products':db.query(Product).filter_by(is_active=True).count(),'customers':db.query(User).filter_by(role='CUSTOMER').count(),'orders':len(os_),'revenue':sum(float(o.total_amount) for o in os_ if o.payment_status=='PAID')}
@app.get('/api/admin/orders')
def adminorders(db:Session=Depends(get_db),_=Depends(admin_user)):return db.query(Order).order_by(Order.created_at.desc()).all()
@app.put('/api/admin/orders/{oid}/status')
def orderstatus(oid:int,x:Status,db:Session=Depends(get_db),_=Depends(admin_user)):
 if x.status not in {'PENDING','CONFIRMED','PROCESSING','SHIPPED','DELIVERED','CANCELLED'}:raise HTTPException(400,'Invalid status')
 o=db.get(Order,oid)
 if not o:raise HTTPException(404,'Order not found')
 o.order_status=x.status;db.commit();return {'status':o.order_status}
