import os
from datetime import datetime,timedelta,timezone
from jose import jwt,JWTError
from passlib.context import CryptContext
from fastapi import Depends,HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from .database import get_db
from .models import User
SECRET=os.getenv('JWT_SECRET','dev-secret'); ALG=os.getenv('JWT_ALGORITHM','HS256'); EXP=int(os.getenv('ACCESS_TOKEN_EXPIRE_MINUTES','60'))
pwd=CryptContext(schemes=['bcrypt'],deprecated='auto'); oauth=OAuth2PasswordBearer(tokenUrl='/api/auth/login')
def hash_password(p): return pwd.hash(p)
def verify_password(p,h): return pwd.verify(p,h)
def token(u): return jwt.encode({'sub':str(u.id),'role':u.role,'exp':datetime.now(timezone.utc)+timedelta(minutes=EXP)},SECRET,algorithm=ALG)
def current_user(t=Depends(oauth),db:Session=Depends(get_db)):
 try: uid=int(jwt.decode(t,SECRET,algorithms=[ALG]).get('sub'))
 except (JWTError,TypeError,ValueError): raise HTTPException(401,'Invalid authentication')
 u=db.get(User,uid)
 if not u: raise HTTPException(401,'Invalid authentication')
 return u
def admin_user(u=Depends(current_user)):
 if u.role!='ADMIN': raise HTTPException(403,'Admin access required')
 return u
