# ThreadCart

Full-stack clothing e-commerce application for Docker/DevOps practice.

## Stack
React + Vite | FastAPI + SQLAlchemy | PostgreSQL | NGINX | Docker Compose | JWT

## Run
```bash
cp .env.example .env
docker compose up --build
```
Open http://localhost
API docs: http://localhost/api/docs

Development admin: `admin@threadcart.local` / `Admin@12345`
Change these values before non-development use.

Architecture: Browser -> NGINX -> Frontend / Backend -> PostgreSQL.
Only NGINX is exposed to the host.
